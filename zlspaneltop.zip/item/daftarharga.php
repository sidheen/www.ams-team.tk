<div class="col-md-12">
<div id="main2" style="display: block;">							<div class="panel mb20 panel-info panel-hovered">
								<div class="panel-heading"><i class="ion ion-ios-pricetags"></i> Daftar Harga</div>
								<div class="panel-body">
									<div class="alert alert-info">
										<h4><i class="ion ion-ios-information"></i> Informasi :</h4>
										- Harga sewaktu-waktu dapat berubah.
									</div>
									
									<div class="alert alert-info">
										<h4><i class="ion ion-ios-pricetags"></i> Daftar Harga Layanan:</h4>
										<table class="table table-striped">
											<thead>
												<tr>
												<th>No</th>
												<th>Jenis Layanan</th>
												<th>Harga per 100</th>
												<th>Minimal Order</th>
												<th>Maximal Order</th>
												</tr>
											</thead>
											<tbody>
												<tr>
												<td>101</td>
												<td>Instagram Followers S1 (Username only) (High Quality &amp; Instant)</td>
												<td>Rp 2.000</td>
												<td>100</td>
												<td>1.800</td>
												</tr>
												<tr>
												<td>102</td>
												<td>Instagram Followers S2 (Username only) (High Quality &amp; Instant)</td>
												<td>Rp 2.000</td>
												<td>100</td>
												<td>15.000</td>
												</tr>
												<tr>
												<td>103</td>
												<td>Instagram Followers S3 (Fast, High Quality, &amp; Instant)</td>
												<td>Rp 2.000</td>
												<td>100</td>
												<td>8.000</td>
												</tr>
												
												<tr>
												<td>105</td>
												<td>Instagram Likes S1 (Fast, High Quality, &amp; Instant)</td>
												<td>Rp 1.600</td>
												<td>100</td>
												<td>10.000</td>
												</tr>
												<tr>
												<td>106</td>
												<td>Instagram Likes S2 (High Quality &amp; Instant)</td>
												<td>Rp 1.600</td>
												<td>100</td>
												<td>40.000</td>
												</tr>
												<tr>
												<td>107</td>
												<td>Twitter Followers S1 (High Quality, Mixed, &amp; Instant)</td>
												<td>Rp 2.600</td>
												<td>100</td>
												<td>15.000</td>
												</tr>
												<tr>


												<tr>
												<td>110</td>
												<td>Youtube Views S1 (High Quality &amp; Instant)</td>
												<td>Rp 1100</td>
												<td>1.000</td>
												<td>1.000.000</td>
												</tr>
												<tr>
												<td>111</td>
												<td>Facebook Photo/Post Likes (High Quality &amp; Instant)</td>
												<td>Rp 2.500</td>
												<td>100</td>
												<td>9.000</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div></div>
						</div>