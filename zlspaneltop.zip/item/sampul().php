<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $kontak = $_POST['kontak'];
  $anime = $_POST['anime'];
  $jualan = $_POST['jualan'];
  $lapak = $_POST['lapak'];
  $harga = '5500';

  if ($get['saldo'] < $harga) { ?>
<div class="alert alert-danger">
Gagal : Saldo tidak mencukupi.
</div>
<? } else if (!$kontak || !$anime) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else {
$no = rand(1111,9999);
$tanggal = date("Y-m-d H:i:s");

	  $simpan = mysql_query("UPDATE user SET saldo=saldo-$harga WHERE username = '$username'");
          $simpan = mysql_query("INSERT INTO historyall VALUES('','$no','$username','Sampul','$harga','Belum','Kontak : [ $kontak ] Daftar Jualan : [ $jualan ] -- Anime : [ $anime ]','$tanggal')");
if($simpan) { 

?>
<strong>Detail Pemesanan Anda !</strong>
<br>======================<br />
<br><strong>No.Order </strong>: <?php echo $no; ?><br />
<br><strong>Pemesanan Sampul</strong><br />
<br><strong>Pembeli </strong>: <?php echo $get ['nama']; ?> <br />
<br><strong>Kontak  </strong>: <?php echo $kontak; ?><br />
<br><strong>Daftar Jualan </strong>: <?php echo $jualan; ?><br />
<br><strong>Anime </strong>: <?php echo $anime; ?><br />
<br><strong>Harga </strong>: <?php echo $harga; ?><br />
<br><strong>Tanggal Pemesanan </strong>: <?php echo $tanggal; ?> <br />
<br>======================<br />
<strong> Status Pending !</strong>
</div>
<div class="alert alert-warning">
Perhatian : Harap menunggu dan memberikan hasil dan No.Order pada Admin.
</div>
<? } else { ?>
ERROR
<? }
} 
?>