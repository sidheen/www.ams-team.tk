<?php
//Script by Assegar Ade Putra
session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>
				<div class="panel-heading">
					<span class="panel-title">Twitter Panel NEW</span>
				</div>
				<div class="panel-body"> 

                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Link/Username</label>
                                            <div class="col-md-9">
				            <div class="input-group">        
                                            <span class="input-group-addon">@</span>                              
                                            <input type="text" class="form-control" name="usrnmlink" id="usrnmlink" placeholder="Link/Username"/>
                                            </div>
                                        </div>          
                                   </div>  
<br />         
<br />
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Layanan</label>
                                        <div class="col-sm-9">
                                            <select class="form-control select" id="layanan" name="layanan">
                                                <option value="6">Twitter Followers Instant | Max Order 15000</option>
<option value="7">Twitter Retweets Instant | Max Order 10000</option>
<option value="8">Twitter Favorites Instant | Max Order 10000</option>
                                               
                                            </select>
                                        </div>
                                    </div>
<br />         
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Jumlah</label>
                                            <div class="col-md-9">
				            <div class="input-group">        
                                            <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Jumlah" onkeyup="getharga(this.value).value;"/>
                                            </div>
                                        </div>          
                                   </div>  
<br />         
<br />
                                    <div class="form-group">
                                        <label for="username" class="col-sm-3 control-label">Harga</label>
                                        <div class="col-sm-9">
                                            <div class="input-group">
                                                <span class="input-group-addon">Rp.</span>
                                                <input type="text" id="harga" name="harga" class="form-control" placeholder="Harga" disabled>
                                            </div>
                                        </div>
                                    </div>
<br />         
<br />
                                        <div data-toggle="modal" data-target="#zonk" class="form-group">
<button class="btn btn-primary" id="btnLogin" onclick="kirim();" ><i class="fa fa-shopping-cart" name="proces" type="submit"></i> Beli Sekarang !</button> 
                                        </div>

<i><pre>
[+] Server 1 Fast Server :
- 100 Follower : 2100 Saldo

</pre></i>
<i><pre>
NOTE :
*Pastikan Link/Username/Target data yang dimasukan Sudah Public(tidak diprivate/digembok)
*untuk order Followers Instagram atau Twitter mohon hanya masukan Username saja (tanpa @)
</pre></i>
                                </div>



<script>
function getharga(jumlah){
var namaaplikasi = $("#layanan").val();
 if (namaaplikasi== "6"){
  var hasil = eval(jumlah) * 32;
  $('#harga').val(hasil);
 } else if (namaaplikasi== "7"){
  var hasil = eval(jumlah) * 28;
  $('#harga').val(hasil);
 } else if (namaaplikasi== "8"){
  var hasil = eval(jumlah) * 28;
  $('#harga').val(hasil);
 } else if (namaaplikasi== "10"){
  var hasil = eval(jumlah) * 18;
  $('#harga').val(hasil);
 } else if (namaaplikasi== "11"){
  var hasil = eval(jumlah) * 17;
  $('#harga').val(hasil);
 } else if (namaaplikasi== "4"){
  var hasil = eval(jumlah) * 14;
  $('#harga').val(hasil);
 } else if (namaaplikasi== "000000"){
  var hasil = eval(jumlah) * 99999999;
  $('#harga').val(hasil);
 }
} 

function kirim()
{
post();
	var usrnmlink = $('#usrnmlink').val();
	var layanan = $('#layanan').val();
	var jumlah = $('#jumlah').val();
	var harga = $('#harga').val();
	$.ajax({
		url	: 'item/proses5.php',
		data	: 'usrnmlink='+usrnmlink+'&layanan='+layanan+'&jumlah='+jumlah+'&harga='+harga,
		type	: 'POST',
		dataType: 'html',
		success	: function(result){
hasil();
	$("#result").html(result);
	}
	});
}
</script>