<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $idignya = $_POST['usrnmlink'];
  $layan = $_POST['layanan'];
  $pakt = $_POST['jumlah'];
  $harg = $_POST['harga'];

if ($get['saldo'] < $harg) { ?>
<div class="alert alert-danger">
Gagal : Saldo tidak mencukupi.
</div>
<?php } else if ($pakt < '100') { ?>
<div class="alert alert-danger">
Gagal : Minimal Jumlah 100.
</div>

<?php  } else if ($harg < '200') { 
  $elok = mysql_query("UPDATE user SET level='Banned' WHERE username = '$username'");
if($elok) { 
header('location:../login.php'); ?>
<div class="alert alert-danger">
Sucess! Kini akun anda telah di Banned dari Web ini :)
</div>
<?php } else { echo "EROR"; }
 } else if (!$idignya) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else {
$no = rand(1111,9999);
$tanggal = date("Y-m-d H:i:s");

	  $simpan = mysql_query("UPDATE user SET saldo=saldo-$harg WHERE username = '$username'");
          $simpan = mysql_query("INSERT INTO historyall VALUES('','$no','$username','$pakt Facebook Post Likes Server $layan','$harg','Sukses','Url/Username : $idignya','$tanggal')");
if($simpan) { 

?>
<?php
    $api_key = "63brdmii21cliyqozqvji5nix6itms3l"; // ini tempat api key panel pedia kamu
    $layanan = "$layan"; // Kode layanan bisa dilihat di Tabel Layanan
    $jumlah = "$pakt"; // Jumlah order
    $username_link = "$idignya"; // Username atau link

$postdata = 'api_key='.$api_key.'&link='.$username_link.'&jenis='.$layanan.'&jumlah='.$jumlah.'';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://panelpedia.id/api.php');
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, false);
$store = curl_exec ($ch);
curl_close ($ch);
$json = json_decode($store,true);
$orderid = $json['id'];

if ($json['result'] == "error") { ?>
    Order error karena <?php echo $json['reason']; ?>
<? } else if ($json['result'] == "success") { ?>

    Pesanan Berhasil !<br>
    ====================================<br>
    Pesanan : <?php echo $pakt; ?> Facebook Post Likes Beres!<br>
    URL Post Facebook : <?php echo $idignya; ?><br>
    Server : <?php echo $layan; ?><br>
    Harga : <?php echo $pakt; ?> Post Likes = <?php echo $harg; ?><br><br>
    Nomor Order :<?php echo $no; ?><br>
    Waktu Tanggal Transaksi : <?php echo $tanggal; ?><br>
    ====================================<br>
    Server Merespon : No. Order <?php echo $orderid; ?><br>

<? } ?>
<? } else { ?>
ERROR
<? }
} 
?>