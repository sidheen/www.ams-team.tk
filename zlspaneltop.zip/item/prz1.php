<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");
$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$hasil = mysql_fetch_array($query);
?>
<?php
function acak($panjang)
{
	$karakter= '1234567890';
	$string = '';
	for ($i = 0; $i < $panjang; $i++) {
		$pos = rand(0, strlen($karakter)-1);
		$string .= $karakter{$pos};
	}
	return $string;
}

  require_once("dcexp450().php");
  $id = $_POST['fbid'];
  $ukey = $_POST['ukey'];
  $date = date("Y-m-d H:i:s");
  $ns = acak(20);
  $paketgems = $_POST['paket'];
  $money = $hasil['saldo'];

if ($paketgems == 1) {
$saldo = 1000;
} else if ($paketgems == 2) {
$saldo = 3000;
} else {
$saldo = a;
}
if($hasil['saldo'] < $saldo) {
  echo "Saldo Tidak Mencukupi";
 } else if ($id == '') {
  echo "Facebook ID Masih Kosong";
 } else {
 $simpan = mysql_query("UPDATE user SET saldo=saldo-$saldo WHERE username = '$username'");
 if($simpan) { ?>
<? } else { ?>
Something Wrong
<?
}
?>