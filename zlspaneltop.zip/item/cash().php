<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $paket = $_POST['paket'];

 $caridata = mysql_query("SELECT * FROM orderphising WHERE id = '$paket'");
 $data = mysql_num_rows($caridata);
 $dapat = mysql_fetch_array($caridata);
 
if ($data == 0) { ?>
<div class="alert alert-danger">
<b>Gagal :</b> Stock kosong.
</div>
<? } else if ($get['saldo'] < $dapat['harga']) { ?>
<div class="alert alert-danger">
<b>Gagal :</b> Saldo tidak mencukupi.
</div>
<? } else {
$noorder = rand(1111,9999);
$tanggal = date("Y-m-d H:i:s");
$harga = $dapat['harga'];
$link = $dapat['link'];
$jenis = $dapat['jenis'];
$email = $dapat['email'];
$passworde = $dapat['passworde'];
	  $simpan = mysql_query("UPDATE user SET saldo=saldo-$harga WHERE username = '$username'");
          $simpan = mysql_query("INSERT INTO historyall VALUES('','$noorder','$username','$link $jenis','$harga','Sukses','-','$tanggal')");
if($simpan) { 

?>

Pembelian sukses !
==================================<br />
Pembelian Web Phising : <?php echo $jenis; ?> sukses.<br />
Pembeli : <?php echo $get['nama']; ?><br />
Jenis :  <?php echo $jenis; ?><br />
Harga : <?php echo $harga; ?><br />
Email : <?php echo $email; ?> <br />
Password Email :  <?php echo $passworde; ?> <br />
Link Web :  <?php echo $link; ?> <br />
Tgl. Transaksi : <?php echo $tanggal; ?> <br />
==================================
</div>

<? 
mysql_query("DELETE FROM orderphising WHERE id='$paket'");
} else { ?>
ERROR
<? }
} 
?>