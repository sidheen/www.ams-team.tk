<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $kontak = $_POST['kontak'];
  $anime = $_POST['anime'];
  $jualan = $_POST['jualan'];
  $lapak = $_POST['lapak'];
  $harga = '2500';

  if ($get['saldo'] < $harga) { ?>
<div class="alert alert-danger">
Gagal : Saldo tidak mencukupi.
</div>
<? } else if (!$kontak || !$anime) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else {
$no = rand(1111,9999);
$tanggal = date("Y-m-d H:i:s");

	  $simpan = mysql_query("UPDATE user SET saldo=saldo-$harga WHERE username = '$username'");
          $simpan = mysql_query("INSERT INTO historyall VALUES('','$no','$username','Cap Order','$harga','Belum','Kontak : [ $kontak ] -- Anime : [ $anime ]','$tanggal')");
if($simpan) { 

?>
<strong>Pembelian Kebutuhan Editing Sukses !</strong>
===================<br />
<strong>No.Order </strong>: <?php echo $no; ?><br />
<strong>Pemesanan Cap Order sukses.<br />
<strong>Pembeli </strong>: <?php echo $get['nama']; ?><br />
<strong>Barang </strong>: Cap Order<br />
<strong>Kontak </strong>: <?php echo $kontak; ?><br />
<strong>Anime </strong>: <?php echo $anime; ?><br />
<strong>Harga </strong>: <?php echo $harga; ?><br />
<strong>Tgl. Transaksi <strong>: <?php echo $tanggal; ?> <br />
<strong>Status </strong>: Pending
====================

<div class="alert alert-warning">
Perhatian : Harap menunggu dan memberikan hasil dan No.Order pada Admin.
</div>
<? } else { ?>
ERROR
<? }
} 
?>