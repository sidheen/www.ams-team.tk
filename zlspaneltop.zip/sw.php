				<div class="panel-heading">
					<span class="panel-title">Social Empires All Resources</span>
				</div>
				<div class="panel-body"> 

                                        <label>FBID</label><br>
		<span class="field"><input type="text" class="form-control" id="fbid" value="<?PHP echo $_POST['fbid'] ;?>"name="fbid" class="input-large" placeholder="Input FB ID"></span>
	<p>
<label>Session ID</label><br>
		<span class="field"><input type="text" class="form-control" id="ukey" value="<?PHP echo $_POST['ukey']; ?>" name="ukey" class="input-large" placeholder="Input User_key"></span>
<br />         
<br />
        
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Paket</label>
                                            <div class="col-md-9">                                        
                                                <select class="form-control select" id="jumlah" name="jumlah">
<option value="100">All Resourcer 100.000</option>
<option value="200">All Resourcer 200.000</option>
<option value="100000">All Resourcer 99999999</option>
                                                </select>
                                            </div>
                                        </div>                              
                                                  
<br />         
<br />
                                          <div data-toggle="modal" data-target="#zonk" class="form-group">
<button class="btn btn-primary btn-block" id="btnLogin" onclick="kirim();" ><i class="fa fa-mail-forward" name="proces" type="submit"></i> Submit</button> 
                                        </div>

<i><pre>
Free (Y) Gunakan Dengan bijak
</pre></i>
                                </div>

<script>
function kirim()
{
post();
	var fbid = $('#fbid').val();
	var ukey = $('#ukey').val();
	
	$.ajax({
		url	: 'item/sw().php',
		data	: 'fbid='+fbid+'&ukey='+ukey+'&jumlah='+jumlah,
		type	: 'POST',
		dataType: 'html',
		success	: function(result){
hasil();
	$("#result").html(result);
	}
	});
}
</script>