<!DOCTYPE html>
<html lang="en">
<head>
  <title>Ketentuan&Persyaratan !</title>
<!-- Meta -->
<meta name="description" content="CS-Panel SMM Panel">
<meta name="keywords" content="SMM Panel,ZLS PANEL,Webpanel,Social Medi Reseller">
<meta name="author" content="Taufan Zeze">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- / Meta -->
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>



    
    <body>

<script language=JavaScript>
<!--

//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// -->
</script>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ZLS PANEL</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
      <li><a href="login.php">Login</a></li> 
      <li><a href="harga.php">Harga</a></li>
      <li><a href="alluser.php">Total Pengguna</a></li> 
      <li><a href="privacy.php">Ketentuan&Persyaratan</a></li> 
    </ul>
  </div>
</nav>
<div class="container">
  <h2>Ketentuan & Persyaratan !</h2>
  <div class="panel panel-primary">
    <div class="panel-heading">Ketentuan & Persyaratan !</div>
      <div class="panel-body">

<div class="alert alert-danger"><strong>
Ketentuan :</br>
  -Tidak boleh Melakukan BUG Saldo & Hack Akun dan lain lain!</br>
-Tidak boleh berbicara Kasar Sesama user!</br>
-Tidak boleh memainkan harga !</br>
-Tidak boleh Menjual Beli akun CS !</br>

-Tidak boleh memainkan harga !</br>


Persyaratan :</br>
-Minimal usia Anda 14 tahun  !</br>
-Pakai Bahasa Sopan & Santun !</br>

-Tidak terkait Dengan Penipuan  !</br>


<center>Regard : ZLS-PANEL Team </center>
</div></strong> 

</div>
							</div></div>
						</div>
              

        </div></strong>
  </div>
</div>
<center><small>Design by : Taufan Zeze</small></center>
