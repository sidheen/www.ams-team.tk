       

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home | Landing Page !</title>
<!-- Meta -->
<meta name="description" content="ZLS PANEL SMM Panel">
<meta name="keywords" content="SMM Panel,ZLS-PANEL,Webpanel,Social Medi Reseller">
<meta name="author" content="Anvield Wijaya">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- / Meta -->
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>



    
    <body>

<script language=JavaScript>
<!--

//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// -->
</script>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ZLS PANEL</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
      <li><a href="login.php">Login</a></li> 
      <li><a href="harga.php">Harga</a></li>
      <li><a href="alluser.php">Total Pengguna</a></li> 
      <li><a href="privacy.php">Ketentuan&Persyaratan</a></li> 
    </ul>
  </div>
</nav>
<div class="row">
<div class="container">
  <h2><strong>Welcome To ZLS PANEL !</strong></h2>
<marquee><div class="alert alert-success">Ingin Daftar Silahkan Klik Menu Harga ! Fitur Baru ? Auto Visitor Website & Phising Web</div></marquee>
   
  <div class="panel panel-primary">
    <div class="panel-heading">Info Your !</div>
      <div class="panel-body">

Follow Admin ! : <iframe src="https://www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2Findopayvoc&width=450&height=80&layout=standard&show_faces=true&appId=724060097729484" width="450" height="80" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
<center>Ip Info :</br>
<script src="//api.find-ip.net/widget.js?width=240&"></script><div class="findiplink">Powered by <a href="zls-panel.top" target="_blank">http://zls-panel.top/</a></div>
<a href="home.php" target="_Blank" title="free hit counter">Total Visitor</a><br/>
<script type="text/javascript" src="http://counter7.freecounter.ovh/private/counter.js?c=cdbbbb0897bcaef1e734658ff67df191"></script>
        


 

        

									
							
						</div></div></div></div></div>
									
							
						
              

       
 <div class="panel panel-primary">
    <div class="panel-heading">Sekilas Pendapat Pelanggan  !</div>
      <div class="panel-body">
<img src="http://i.imgur.com/swG15NJ.png" alt="Testi" height="50" width="250">-><img src="http://i.imgur.com/z0xCDl3.png" alt="Testi" height="50" width="250">

				</div></div></div></div>
<h3>Lanjut Bagaimana Pendapat Anda ?</h3>		
  <div class="panel panel-primary">
    <div class="panel-heading">Komentar Sekarang Melalui Facebook  !</div>
      <div class="panel-body">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.6&appId=724060097729484";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

 <div class="fb-comments"></div>

        

									
							</div></div></div></div>
						
    </div></strong></div>



    <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582ECSaLdwqSpnsBYD%2bkSCuKr4YBUlZm9INJegrooRM1Rluy8g5vwgZLezu3sBoNRzRJu1XmqZnks4dw%2bazJtsWTAjd0w16Yt%2bf3i9ta8t5Q%2fTn0D%2fhL%2bQfF9mEmRxVP3B1S40pE4Fa2URPVajqjyWqmOEYuCv9U%2fInGChA5XIG3ng%2fd3B36AVT0RT6EkZIFUlBt1egtE7kyHWH9fOsoWsPTzi3M4mzP06nRAqrXJ1jOxt0fUIELlIlm6A3%2fk9fEh%2bAK8IDhtYKCuhWCcmBMxdVZwN6pASqyWKbuLQP%2b5pVoCfJtcA1Q51haL0FktjCFsLfY9VBO8T8%2fDuTEJEvI%2brrqbtQUs0wMaHLqnJhN61dqw%2bfwWCpF5f0JACv%2ffOGm5H%2f1vZ47zL0Wkf5MRQTvIXQWFjEEng3cp%2fU185Zjqw3iNjZEMTq0Ct0aBZBPatll3%2bqVvj3wp9JHNAJgVwP3bgG2ww2tGyMY5Xozz19Xj8VVV7LXbDMdZLAWCJDM5JRCs4Ejd7QXnIQiIW" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>


</html>