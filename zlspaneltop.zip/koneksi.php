<?php
// Script by Anvield Wijaya

$host = "localhost";
$user = "zlspanel_db";
$pass = "zlspanel_db";
$db = "zlspanel_db";
$konek = mysql_connect($host, $user, $pass) or die ('Koneksi Gagal! ');
mysql_select_db($db);
?>