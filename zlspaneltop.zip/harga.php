<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pricing !</title>
<!-- Meta -->
<meta name="description" content="CS-Panel SMM Panel">
<meta name="keywords" content="SMM Panel,ZLS PANEL,Webpanel,Social Medi Reseller">
<meta name="author" content="Taufan Zeze">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- / Meta -->
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>



    
    <body>

<script language=JavaScript>
<!--

//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// -->
</script>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ZLS PANEL</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
      <li><a href="login.php">Login</a></li> 
      <li><a href="harga.php">Harga</a></li>
      <li><a href="alluser.php">Total Pengguna</a></li> 
      <li><a href="privacy.php">Ketentuan&Persyaratan</a></li> 
    </ul>
  </div>
</nav>
<div class="container">
  <h2>Daftar harga !</h2>
  <div class="panel panel-primary">
    <div class="panel-heading">Harga Layanan !</div>
      <div class="panel-body">
       
									<div class="alert alert-info">
										<h4><i class="ion ion-ios-information"></i> Informasi :</h4>
										- Harga sewaktu-waktu dapat berubah.
                                                                        <h4><i class="ion ion-ios-information"></i> Informasi :</h4>
-List Admin : 
Taufan Zeze Dan Faidaan Acnologia
									</div>
									
									<div class="alert alert-info">
										<h4><i class="ion ion-ios-pricetags"></i> Daftar Harga Layanan:</h4>
										<table class="table table-striped">
											<thead>
												<tr>
												<th>No</th>
												<th>Jenis Layanan</th>
												<th>Harga per 100</th>
												<th>Minimal Order</th>
												<th>Maximal Order</th>
												</tr>
											</thead>
											<tbody>
												<tr>
												<td>1</td>
												<td>Instagram Followers S1 (Username only) (High Quality &amp; Instant)</td>
												<td>Rp 2.000</td>
												<td>100</td>
												<td>1.800</td>
												</tr>
												<tr>
												<td>2</td>
												<td>Instagram Followers S2 (Username only) (High Quality &amp; Instant)</td>
												<td>Rp 2.000</td>
												<td>100</td>
												<td>15.000</td>
												</tr>
												<tr>
												<td>3</td>
												<td>Instagram Followers S3 (Fast, High Quality, &amp; Instant)</td>
												<td>Rp 2.000</td>
												<td>100</td>
												<td>8.000</td>
												</tr>
												
												<tr>
												<td>4</td>
												<td>Instagram Likes S1 (Fast, High Quality, &amp; Instant)</td>
												<td>Rp 1.600</td>
												<td>100</td>
												<td>10.000</td>
												</tr>
												
												<tr>
												<td>5</td>
												<td>Twitter Followers S1 (High Quality, Mixed, &amp; Instant)</td>
												<td>Rp 1.600</td>
												<td>100</td>
												<td>15.000</td>
												</tr>
												<tr>


												<tr>
												<td>6</td>
												<td>Youtube Views S1 (High Quality &amp; Instant)</td>
												<td>Rp 13.500</td>
												<td>1.000</td>
												<td>1.000.000</td>
												</tr>
												<tr>
												<td>7</td>
												<td>Facebook Photo/Post Likes (High Quality &amp; Instant)</td>
												<td>Rp 1.900</td>
												<td>100</td>
												<td>9.000</td>
												</tr>
											</tbody>
										</table>
									</div>

<strong><div class="alert alert-success">

 Harga Kebutuhan Lainnya : </br>
=========================================================</br>
               [+]Kebutuhan Editing</br>
           -Sampul = 2,500</br>
           -Logo   = 2,500</br>
           -Cap    = 2,500</br>
           -Photo Profile = 2,500</br>
=========================================================</br>
[+]Hosting :</br>
-cPanel Mini = 4,000</br>
-cPanel Medium = 8,000</br>
-cPanel unlimited = 13,000</br>
=========================================================</br>
[+]Social Point game :</br>
-Dragon City Gold 90M & Exp 550M</br>
-Social Wars All Resourcer</br>
-Social Empires Gold&Cash</br>
=========================================================</br>
Harga Pendftaran :</br>

Member = 15k Saldo Pertama 5,000</br>
Agen   = 30k Saldo Pertama 15,000</br>
Reseller = 100k Saldo Pertama 50,000</br>

pendaftaran via Pulsa T-sel/Bank BRI Langsung saja daftar -><a href="https://www.facebook.com/messages/fzz012" class="btn btn-info" role="button">Klik disini !</a></br>
=========================================================</br>
								</div>
							</div></div>
						</div>
              

        </div></strong>
  </div>
</div>

<center><small>Design by : Taufan zeze</small></center>

    <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582ECSaLdwqSpnsBYD%2bkSCuKr4YBUlZm9INJegrooRM1Rluy8g5vwgZLezu3sBoNRzRJu1XmqZnks4dw%2bazJtsWTAjd0w16Yt%2bf3i9ta8t5Q%2fTn0D%2fhL%2bQfF9mEmRxVP3B1S40pE4Fa2URPVajqjyWqmOEYuCv9U%2fInGChA5XIG3ng%2fd3B36AVT0RT6EkZIFUlBt1egtE7kyHWH9fOsoWsPTzi3M4mzP06nRAqrXJ1jOxt0fUIELlIlm6A3%2fk9fEh%2bAK8IDhtYKCuhWCcmBMxdVZwN6pASqyWKbuLQP%2b5pVoCfJtcA1Q51haL0FktjCFsLfY9VBO8T8%2fDuTEJEvI%2brrqbtQUs0wMaHLqnJhN61dqw%2bfwWCpF5f0JACv%2ffOGm5H%2f1vZ47zL0Wkf5MRQTvIXQWFjEEng3cp%2fU185Zjqw3iNjZEMTq0Ct0aBZBPatll3%2bqVvj3wp9JHNAJgVwP3bgG2ww2tGyMY5Xozz19Xj8VVV7LXbDMdZLAWCJDM5JRCs4Ejd7QXnIQiIW" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>


</html>
