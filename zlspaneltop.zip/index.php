<?php
// Script by Sebastian Wirajaya

session_start();
if(!isset($_SESSION['username'])) {
header('location:home.php'); }
else { $username = $_SESSION['username']; }
require_once("koneksi.php");


$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);

if ($get['level'] == 'Banned') { 
          header("location:logout.php");
} else {

$user = mysql_query("SELECT * FROM user");
$transaksi = mysql_query("SELECT * FROM historyall");
$totaluser = mysql_num_rows($user);
$totaltransaksi = mysql_num_rows($transaksi);

$password = $get['password'];
$fbid = $get['fbid'];
$nama = $get['nama'];
$level = $get['level'];
$saldo = "IDR " . number_format($get['saldo'],2,',','.');
$uplink = $get['uplink'];
?>


<!DOCTYPE html>
<html lang="en">
    

<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>ZLS PANEL - SMM Panel</title>

        <!-- Bootstrap -->
        <link href="http://flicksbootstrap.com/demo/be-admin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="http://flicksbootstrap.com/demo/be-admin/css/waves.min.css" type="text/css" rel="stylesheet">
        <!--        <link rel="stylesheet" href="css/nanoscroller.css">-->
        <link href="http://flicksbootstrap.com/demo/be-admin/css/menu-light.css" type="text/css" rel="stylesheet">
        <link href="http://flicksbootstrap.com/demo/be-admin/css/style.css" type="text/css" rel="stylesheet">
        <link href="http://flicksbootstrap.com/demo/be-admin/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

 
        <![endif]-->

    </head>
    <body>
<script src="http://repository.chatwee.com/scripts/f49ce57a6b4e1e9d095039edfd63d23e.js" type="text/javascript" charset="UTF-8"></script>
        <!-- Static navbar -->

        <nav class="navbar navbar-default yamm navbar-fixed-top">
            <div class="container-fluid">
                <button type="button" class="navbar-minimalize minimalize-styl-2  pull-left "><i class="fa fa-bars"></i></button>
                <span class="search-icon"><i class="fa fa-search"></i></span>
                <div class="search" style="display: none;">
                    <form role="form">
                        <input type="text" class="form-control" autocomplete="off" placeholder="Write something and press enter">
                        <span class="search-close"><i class="fa fa-times"></i></span>
                    </form>
                </div>
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">ZLS PANEL</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle button-wave" data-toggle="dropdown" aria-expanded="true">Mega Menu<span class="caret"></span></a>
                            <ul class="dropdown-menu mega-dropdown-menu" style="width: 900px;">
                                <li>
                                    <div class="yamm-content">
                                        <div class="row ">
                                            <div class="col-sm-3 ">

                                                <h3 class="yamm-category">Layout</h3>
                                                <ul class="list-unstyled ">
                                                    <li><a href="#">Admin style 1</a></li>
                                                    <li><a href="#">Admin style 2</a></li>
                                                    <li><a href="#">Admin style 3</a></li>
                                                    <li><a href="#">Admin style 4</a></li>   
                                                </ul>


                                            </div>
                                            <div class="col-sm-3">

                                                <h3 class="yamm-category">Ui Kit</h3>
                                                <ul class="list-unstyled ">
                                                    <li><a href="#">Typography</a></li>
                                                    <li><a href="#">Buttons</a></li>
                                                    <li><a href="#">Font Awesome</a></li>
                                                    <li><a href="#">Tabs & Alerts</a></li>
                                                </ul>


                                            </div>
                                            <div class="col-sm-3">

                                                <h3 class="yamm-category">Analytics</h3>
                                                <ul class="list-unstyled ">
                                                    <li><a href="#">Flot</a></li>
                                                    <li><a href="#">Sparklines</a></li>
                                                    <li><a href="#">Morris</a></li>
                                                    <li><a href="#">Chart Js</a></li>
                                                </ul>


                                            </div>
                                            <div class="col-sm-3">
                                                <h3 class="yamm-category">Architecto</h3>
                                                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium. totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle button-wave" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li role="separator" class="divider"></li>
                                <li class="dropdown-header">Nav header</li>
                                <li><a href="#">Separated link</a></li>
                                <li><a href="#">One more separated link</a></li>
                            </ul>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right navbar-top-drops">
                        <li class="dropdown"><a href="#" class="dropdown-toggle button-wave" data-toggle="dropdown"><i class="fa fa-envelope"></i> <span class="badge badge-xs badge-info">6</span></a>

                            <ul class="dropdown-menu dropdown-lg">
                                <li class="notify-title">
                                    3 New messages 
                                </li>
                                <li class="clearfix">
                                    <a href="#">
                                        <span class="pull-left">
                                            <img src="http://flicksbootstrap.com/demo/be-admin/images/avtar-1.jpg" alt="" class="img-circle" width="30">
                                        </span>
                                        <span class="block">
                                            John Doe
                                        </span>
                                        <span class="media-body">
                                            Lorem ipsum dolor sit amet
                                            <em>28 minutes ago</em>
                                        </span>
                                    </a>
                                </li>
                                <li class="clearfix">
                                    <a href="#">
                                        <span class="pull-left">
                                            <img src="http://flicksbootstrap.com/demo/be-admin/images/avtar-2.jpg" alt="" class="img-circle" width="30">
                                        </span>
                                        <span class="block">
                                            John Doe
                                        </span>
                                        <span class="media-body">
                                            Lorem ipsum dolor sit amet
                                            <em>28 minutes ago</em>
                                        </span>
                                    </a>
                                </li>
                                <li class="clearfix">
                                    <a href="#">
                                        <span class="pull-left">
                                            <img src="http://flicksbootstrap.com/demo/be-admin/images/avtar-3.jpg" alt="" class="img-circle" width="30">
                                        </span>
                                        <span class="block">
                                            John Doe
                                        </span>
                                        <span class="media-body">
                                            Lorem ipsum dolor sit amet
                                            <em>28 minutes ago</em>
                                        </span>
                                    </a>
                                </li>
                                <li class="read-more"><a href="#">View All Messages <i class="fa fa-angle-right"></i></a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="#" class="dropdown-toggle button-wave" data-toggle="dropdown"><i class="fa fa-bell"></i> <span class="badge badge-xs badge-warning">6</span></a>

                            <ul class="dropdown-menu dropdown-lg">
                                <li class="notify-title">
                                    3 New messages 
                                </li>
                                <li class="clearfix">
                                    <a href="#">
                                        <span class="pull-left">
                                            <i class="fa fa-envelope"></i>
                                        </span>

                                        <span class="media-body">
                                            15 New Messages
                                            <em>20 Minutes ago</em>
                                        </span>
                                    </a>
                                </li>
                                <li class="clearfix">
                                    <a href="#">
                                        <span class="pull-left">
                                            <i class="fa fa-twitter"></i>
                                        </span>

                                        <span class="media-body">
                                            13 New Followers
                                            <em>2 hours ago</em>
                                        </span>
                                    </a>
                                </li>
                                <li class="clearfix">
                                    <a href="#">
                                        <span class="pull-left">
                                            <i class="fa fa-download"></i>
                                        </span>

                                        <span class="media-body">
                                            Download complete
                                            <em>2 hours ago</em>
                                        </span>
                                    </a>
                                </li>
                                <li class="read-more"><a href="#">View All Alerts <i class="fa fa-angle-right"></i></a></li>
                            </ul>
                        </li>
      
                    </ul>
                </div><!--/.nav-collapse -->
            </div><!--/.container-fluid -->
        </nav>
        <section class="page">

            <nav class="navbar-aside navbar-static-side" role="navigation">
                <div class="sidebar-collapse nano">
                    <div class="nano-content">
                        <ul class="nav metismenu" id="side-menu">
                            <li class="nav-header">
                                <div class="dropdown side-profile text-left"> 
                                    <span style="display: block;">
                                        <img alt="image" class="img-circle" src="https://graph.facebook.com/<?php echo $fbid; ?>/picture" width="40">
                                    </span>
                                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                        <span class="clear" style="display: block;"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $nama; ?> <b class="caret"></b></strong>
                                            </span></span> </a>
                                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                        <li><a href="javascript:;" onclick="buka('item/history');"><i class="fa fa-user"></i>My History</a></li>
                                        <li><a href="javascript:;" onclick="buka('panel/changepw');"><i class="fa fa-key"></i>Change Password</a></li>                         
                                        <li><a href="javascript:;" onclick="buka('panel/changename');"><i class="fa fa-envelope"></i>Change Name</a></li>
                                        <li><a href="#"><i class="fa fa-barcode"></i>My Task</a></li>
                                        <li class="divider"></li>
                                        <li><a href="#"><i class="fa fa-lock"></i>Screen lock</a></li>
                                        <li><a href="logout.php"><i class="fa fa-key"></i>Logout</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <a href="index.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard </span><span class="fa arrow"></span></a>
                               
                            </li>
                              <li>
                                <a href="index.php"><i class="fa fa-instagram"></i> <span class="nav-label">Social Media </span><span class="fa arrow"></span></a>
                               
                            
                          
                            <ul class="nav nav-second-level collapse">
                                <li> <a href="javascript:;" onclick="buka('item/igfolls');">
                                    <i class="fa fa-instagram"></i> Instagram Follower </a></li>
<li> <a href="javascript:;" onclick="buka('item/twitfollow');">
                                    <i class="fa fa-twitter"></i> Twitter Panel [NEW] </a></li>
          <li> <a href="javascript:;" onclick="buka('item/iglikes');">
                                    <i class="fa fa-instagram"></i> Instagram Likes </a></li>
          <li> <a href="javascript:;" onclick="buka('item/yt');">
                                    <i class="fa fa-youtube"></i> Youtube Viewer </a></li>
          <li> <a href="javascript:;" onclick="buka('item/fblikes');">
                                    <i class="fa fa-facebook"></i> Facebook Likes </a></li> 
 <li> <a href="javascript:;" onclick="buka('item/webtraff');">
                                    <i class="fa fa-shield"></i> Website traffic </a></li>
        

                            </ul>
                        </li>
        <li>
                                <a href="index.php"><i class="fa fa-picture-o"></i> <span class="nav-label">Keb.Editing</span><span class="fa arrow"></span></a>
                               
                            
                          
                            <ul class="nav nav-second-level collapse">
                                      <li>
                                <a href="javascript:;" onclick="buka('item/pp');">
                                    <i class="fa fa-angle-double-right"></i> PP
                                </a>
                            </li>

                            <li>
                                <a href="javascript:;" onclick="buka('item/sampul');">
                                    <i class="fa fa-angle-double-right"></i> Sampul
                                </a>
                            </li>

                            <li>
                                <a href="javascript:;" onclick="buka('item/lapak');">
                                    <i class="fa fa-angle-double-right"></i> Lapak Close/Open
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;" onclick="buka('item/caporder');">
                                    <i class="fa fa-angle-double-right"></i> Cap Order
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;" onclick="buka('item/logoshop');">
                                    <i class="fa fa-angle-double-right"></i> Logo Shop
                                </a>
                            </li>

        

                            </ul>
                        </li>
<li>

                                <a href="index.php"><i class="fa fa-shield"></i> <span class="nav-label">Web Phising </span><span class="fa arrow"></span></a>
                               
                            
                          
                        <ul class="nav nav-second-level collapse">
                                 <li> <a href="javascript:;" onclick="buka('item/phising');">
                                    <i class="fa fa-angle-double-right"></i> Web Phising </a></li>
           

                            </ul>
                        </li>     
<li>

                                <a href="index.php"><i class="fa fa-gamepad"></i> <span class="nav-label">Keb.Game Fb </span><span class="fa arrow"></span></a>
                               
                            
                          
                        <ul class="nav nav-second-level collapse">
                                 <li> <a href="javascript:;" onclick="buka('item/sw');">
                                    <i class="fa fa-angle-double-right"></i> Social Wars </a></li>
           <li> <a href="javascript:;" onclick="buka('item/se');">
                                    <i class="fa fa-angle-double-right"></i> Social Empires </a></li>
									   <li> <a href="javascript:;" onclick="buka('item/dcxp');">
                                    <i class="fa fa-angle-double-right"></i> Dragon City Exp 550M [Update]</a></li>
           <li> <a href="javascript:;" onclick="buka('item/dcgold');">
                                    <i class="fa fa-angle-double-right"></i> Dragon City Gold 90M [Update]</a></li>

                            </ul>
                        </li>     
<li>
                                <a href="index.php"><i class="fa fa-shopping-cart"></i> <span class="nav-label">Keb.Hosting </span><span class="fa arrow"></span></a>
                               
                            
                          
                            <ul class="nav nav-second-level collapse">
                                 <li> <a href="javascript:;" onclick="buka('item/cpanel');">
                                    <i class="fa fa-angle-double-right"></i> cPanel </a></li>
         

                            </ul>
                        </li> 
 <li>
                                <a href="#"><i class=""></i> <span class="nav-label">Setting </span></a>   </li>
<li>
                                <a href="#"><i class="fa fa-users"></i> <span class="nav-label">User Panel </span><span class="fa arrow"></span></a>
                               
                            
                          
                            <ul class="nav nav-second-level collapse">
                                 <li> <a href="javascript:;" onclick="buka('panel/adduser');">
                                    <i class="fa fa-angle-double-right"></i> Tambah User </a></li>
 <li> <a href="javascript:;" onclick="buka('panel/topupsaldo');">
                                    <i class="fa fa-angle-double-right"></i> Deposit Top Up Saldo </a></li>

        <li> <a href="javascript:;" onclick="buka('panel/vocsaldo');">
                                    <i class="fa fa-angle-double-right"></i> Buat Code Voucher Saldo </a></li>    
 <li> <a href="javascript:;" onclick="buka('panel/cekorder');">
                                    <i class="fa fa-angle-double-right"></i> Cek Orderan </a></li>
<li> <a href="javascript:;" onclick="buka('panel/cekuser');">
                                    <i class="fa fa-angle-double-right"></i> Cek User </a></li>
        <li> <a href="javascript:;" onclick="buka('panel/gantistatusorder');">
                                    <i class="fa fa-angle-double-right"></i> Ganti Status Order !</a></li>  
 <li> <a href="javascript:;" onclick="buka('panel/tambahstockv');">
                                    <i class="fa fa-angle-double-right"></i> Tambah Stock Phising </a></li>
 <li> <a href="javascript:;" onclick="buka('panel/hapususer');">
                                    <i class="fa fa-angle-double-right"></i> Hapus User </a></li>
        </ul>
      </li> 

                        </ul>

                    </div>
                </div>
            </nav>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Dashboard <small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="#"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Dashboard</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- end .page title-->
                    <div class="row">
                        <div class="col-sm-6 col-md-3 margin-b-30">
                            <div class="tile">
                                <div class="tile-title clearfix">
                                    Total orders
                                    <span class="pull-right"><i class="fa fa-caret-up"></i> </span>
                                </div><!--.tile-title-->
                                <div class="tile-body clearfix">
                                    <i class="fa fa-cart-plus"></i>
                                    <p class="pull-right"><?php echo $totaltransaksi; ?></p>
                                </div><!--.tile-body-->
                                <div class="tile-footer">
                                    <a href="#">View Details...</a>
                                </div><!--.tile footer-->
                            </div><!-- .tile-->
                        </div><!--end .col-->
                        <div class="col-sm-6 col-md-3 margin-b-30">
                            <div class="tile">
                                <div class="tile-title clearfix">
                                    Total User</span>
                                </div><!--.tile-title-->
                                <div class="tile-body clearfix">
                                    <i class="fa fa-users"></i>
                                    <p class="pull-right"><?php echo $totaluser; ?></p>
                                </div><!--.tile-body-->
                                <div class="tile-footer">
                                    <a href="#">View Details...</a>
                                </div><!--.tile footer-->
                            </div><!-- .tile-->
                        </div><!--end .col-->
                        <div class="col-sm-6 col-md-3 margin-b-30">
                            <div class="tile">
                                <div class="tile-title clearfix">
                                    Total Saldo
                                    <span class="pull-right"><i class="fa fa-money"></i> </span>
                                </div><!--.tile-title-->
                                <div class="tile-body clearfix">
                                    <i class="fa fa-money"></i>
                                    <p class="pull-right"><?php echo $saldo; ?></p>
                                </div><!--.tile-body-->
                                <div class="tile-footer">
                                    <a href="https://www.facebook.com/indopayvoc">Get Saldo</a>
                                </div><!--.tile footer-->
                            </div><!-- .tile-->
                        </div><!--end .col-->
                        <div class="col-sm-6 col-md-3 margin-b-30">
                            <div class="tile">
                                <div class="tile-title clearfix">
                                    Uplink
                                    <span class="pull-right"><i class="fa fa-link"></i> </span>
                                </div><!--.tile-title-->
                                <div class="tile-body clearfix">
                                    <i class="fa fa-link"></i>
                                    <p class="pull-right"><?php echo $uplink; ?></p>
                                </div><!--.tile-body-->
                                <div class="tile-footer">
                                    <a href="#">View Details...</a>
                                </div><!--.tile footer-->
                            </div><!-- .tile-->
                        </div><!--end .col-->
                    </div><!--end .row-->
                 <div class="alert alert-primary">
  <strong><marquee>
<?php
$hariini = date("Y-m-d");
$i=0;

$tampil = mysql_query("SELECT * FROM historyall WHERE tanggal = '$hariini' ORDER BY id DESC");
$data = mysql_num_rows($tampil);

if ($data == 0) {
echo "<b>( ".$hariini." )</b> Hari ini tidak ada transaksi...";
} else {


while($data = mysql_fetch_array($tampil))
 {
 $i++;
 
echo " <b>( ".$data[tanggal]." )</b> <i>".$data[pembeli]."</i> telah melakukan pembelian ".$data[barang]." ~ ";
}
}
?>
</marquee>
</div></strong>
    <div class="row">
                        <div class="col-md-14">
                            <div class="panel panel-default ">
                                <!-- Start .panel -->
                                <div class="panel-heading">
                                    <h4 class="panel-title"> Informasi !</h4>
                                    <div class="panel-actions">
                                        <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                                        <a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <h3>Informasi terkini ! </h3>
<div class="alert alert-danger">
 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Informasi!</strong>Submit Follower Sampai 1000 Lebih ? Jangan Dulu Server kami lagi lemah !.
</div>
                                        <div class="alert alert-success">
 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Succesfully!</strong> update fitur Website traffic ,Facebook Viewer Videos,dan facebook Likes Fanspage.
</div>
<div class="alert alert-danger">
 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Informasi!</strong> Besok Atau Rabu Fitur Social Media Bisa Digunakan !  Sekilas info!.
</div>
                                    
                                </div>
                            </div><!-- End .panel -->  
                        </div><!--end .col-->

                    <div class="row">
                        <div class="col-md-8">
                            <div class="panel panel-default ">
                                <!-- Start .panel -->
                                <div class="panel-heading">
                                    <h4 class="panel-title"> Example Order !</h4>
                                    <div class="panel-actions">
                                        <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                                        <a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
                                    </div>
                                </div>
                                <div id="konten" class="panel-body">
                                    <h3>Order Disini ! </h3>
                                      
                                    
                                </div>
                            </div><!-- End .panel -->  
                        </div><!--end .col-->
                      
                          <div class="row">
                     <div class="col-md-4">
                            <div class="panel panel-default ">
                                <!-- Start .panel -->
                                <div class="panel-heading">
                                    <h4 class="panel-title"> Result Order !</h4>
                                    <div class="panel-actions">
                                        <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                                        <a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
                                    </div>
                                </div>
                                <div id="result" class="panel-body">
                                  

                                </div></div>
                            </div><!-- End .panel -->  
                        </div><!--end .col-->

                
                        
                </div> 
            </div>
        </section>

        <script type="text/javascript" src="http://flicksbootstrap.com/demo/be-admin/js/jquery.min.js"></script>
        <script type="text/javascript" src="http://flicksbootstrap.com/demo/be-admin/bootstrap/js/bootstrap.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/metisMenu.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/jquery-jvectormap-1.2.2.min.js"></script>
        <!-- Flot -->
        <script src="http://flicksbootstrap.com/demo/be-admin/js/flot/jquery.flot.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/flot/jquery.flot.tooltip.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/flot/jquery.flot.resize.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/flot/jquery.flot.pie.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/chartjs/Chart.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/pace.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/waves.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/morris_chart/raphael-2.1.0.min.js"></script>
        <script src="http://flicksbootstrap.com/demo/be-admin/js/morris_chart/morris.js"></script>

        <script src="http://flicksbootstrap.com/demo/be-admin/js/jquery-jvectormap-world-mill-en.js"></script>
        <!--        <script src="js/jquery.nanoscroller.min.js"></script>-->
        <script type="text/javascript" src="http://flicksbootstrap.com/demo/be-admin/js/custom.js"></script>
        <!-- ChartJS-->
        <script src="http://flicksbootstrap.com/demo/be-admin/js/chartjs/Chart.min.js"></script>

        <script>
            $(document).ready(function () {

                var lineData = {
                    labels: ["January", "February", "March", "April", "May"],
                    datasets: [
                        {
                            label: "Example dataset",
                            fillColor: "rgba(120,120,120,0.5)",
                            strokeColor: "rgba(120,120,120,1)",
                            pointColor: "rgba(120,120,120,1)",
                            pointStrokeColor: "#fff",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "rgba(220,220,220,1)",
                            data: [65, 59, 80, 81, 56]
                        },
                        {
                            label: "Example dataset",
                            fillColor: "rgba(223, 61, 130,0.5)",
                            strokeColor: "rgba(223, 61, 130,0.7)",
                            pointColor: "rgba(223, 61, 130,1)",
                            pointStrokeColor: "#fff",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "rgba(223, 61, 130,1)",
                            data: [28, 48, 40, 19, 86]
                        }
                    ]
                };

                var lineOptions = {
                    scaleShowGridLines: true,
                    scaleGridLineColor: "rgba(0,0,0,.05)",
                    scaleGridLineWidth: 1,
                    bezierCurve: true,
                    bezierCurveTension: 0.4,
                    pointDot: true,
                    pointDotRadius: 4,
                    pointDotStrokeWidth: 1,
                    pointHitDetectionRadius: 20,
                    datasetStroke: true,
                    datasetStrokeWidth: 2,
                    datasetFill: true,
                    responsive: true
                };


                var ctx = document.getElementById("lineChart").getContext("2d");
                var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

            });
        </script>


        <script type="text/javascript">
            $(function () {

                var barData = {
                    labels: ["January", "February", "March", "April", "May", "June", "July"],
                    datasets: [
                        {
                            label: "My First dataset",
                            fillColor: "rgba(220,220,220,0.5)",
                            strokeColor: "rgba(220,220,220,0.8)",
                            highlightFill: "rgba(220,220,220,0.75)",
                            highlightStroke: "rgba(220,220,220,1)",
                            data: [65, 59, 80, 81, 56, 55, 40]
                        },
                        {
                            label: "My Second dataset",
                            fillColor: "rgba(223, 61, 130,0.5)",
                            strokeColor: "rgba(223, 61, 130,0.8)",
                            highlightFill: "rgba(223, 61, 130,0.75)",
                            highlightStroke: "rgba(223, 61, 130,1)",
                            data: [28, 48, 40, 19, 86, 27, 90]
                        }
                    ]
                };

                var barOptions = {
                    scaleBeginAtZero: true,
                    scaleShowGridLines: true,
                    scaleGridLineColor: "rgba(0,0,0,.05)",
                    scaleGridLineWidth: 1,
                    barShowStroke: true,
                    barStrokeWidth: 2,
                    barValueSpacing: 5,
                    barDatasetSpacing: 1,
                    responsive: true
                };


                var ctx = document.getElementById("barChart").getContext("2d");
                var myNewChart = new Chart(ctx).Bar(barData, barOptions);

            });
        </script>
        <!-- Google Analytics:  -->
        <script>
            (function (i, s, o, g, r, a, m)
            {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function ()
                {
                    (i[r].q = i[r].q || []).push(arguments);
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '../../../www.google-analytics.com/analytics.js', 'ga');
            ga('create', 'UA-3560057-28', 'auto');
            ga('send', 'pageview');
        </script>
    <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582ECSaLdwqSpnijV1%2fPO6OZslhLrNGTmWZ0FXZpTcgNfm1q9PPF%2bmYm1oaH8pDmiqOarU4np%2bDgWuay65Q%2byseBnBkKdE2FjpyIerdAaR3Rk6tiBEdVlr7DWqhjRFVHTv8GPs573dPMHl47wci%2bPzvXoYS3XFWcvA%2b%2f0bUZrlTby1N%2bnw3qBWT1LTabkVVB20362KgzMXQFVcEIbjGxSrapVLCSX56UdLvgywrh%2bqZaPwqsja2ccExhhLQnvMzeKXwOXG76erSeZk%2ftreniezg7dgQw5TgzCGkp1BTsecgGqInbjpvGvVfaJJ66E%2faBmcKJrZt7uEBNyxQG6rMQHbOWwIHDW8hmtkdZLw2aoNx5TiNhgLYhKOR80%2fOCgTO8orj%2fbofC6pLmAAIJQ9rb%2bJC7v0VOJ2MxHAX92ZHr3nUuv3D5zoT1cbgdiQ7bcWYxT4lFiJmFy%2fMNuAcirA3ackHXCyl3l3dGKex7HZvu6JFanmXhruurj5xGwriYa6Qe%2bMIg%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>


</html>
<script>
// Script by Anvield Wijaya

function buka(nama) {
$("#konten").html('<div class="panel-heading"><span class="panel-title">Loading Konten...</span></div><div class="panel-body"><div class="progress progress-striped active"><div class="progress-bar progress-bar-success" style="width: 100%"></div></div></div>');
	$.ajax({
		url	: nama+'.php',
		type	: 'GET',
		dataType: 'html',
		success	: function(isi){
			$("#konten").html(isi);
		},
	});
}

function post(){
    $('#result').html('<div class="progress progress-striped active"><div class="progress-bar progress-bar-success" style="width: 100%"></div></div></div></div>');
    $("input").attr("disabled", "disabled");
    $("select").attr("disabled", "disabled");
    $("button").attr("disabled", "disabled");
    $("textarea").attr("disabled", "disabled");
}
function hasil(){
    $("input").removeAttr("disabled");
    $("select").removeAttr("disabled");
    $("button").removeAttr("disabled");
    $("textarea").removeAttr("disabled");
}
</script>

    </body>

</html>
<?php
}
?>