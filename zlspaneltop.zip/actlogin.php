<?php
// Script by Anvield Wijaya
session_start();
require_once("koneksi.php");
$username = $_POST['username'];
$pass = $_POST['password'];
$cekuser = mysql_query("SELECT * FROM user WHERE username = '$username'");
$jumlah = mysql_num_rows($cekuser);
$hasil = mysql_fetch_array($cekuser);
if($jumlah == 0) {
   header("location:login.php?pesan=1&isi=Username : $username Not Registered.");
} else {
   if($pass <> $hasil['password']) {
     header("location:login.php?pesan=1&isi=Password wrong Please Input Password.");
   } else {
     $_SESSION['username'] = $hasil['username'];
     header('location:/');
   }
}
?>