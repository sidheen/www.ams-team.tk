<?php
// Script by Sebastian Wirajaya Licensed

session_start();
if(!isset($_SESSION['username'])) {
header('location:login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$hasil = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $username1 = $_POST['username'];

  $cekuser = mysql_query("SELECT * FROM user WHERE username = '$username1'");  
  $dapat = mysql_fetch_array($cekuser);
  $cek = mysql_num_rows($cekuser);

  if($dapat['level'] == Reseller) { ?>
<div class="alert alert-danger">
Gagal : Username sudah menjadi Reseller.
</div>
<? } else if($cek == 0) { ?>
<div class="alert alert-danger">
Gagal : Username tidak terdaftar.
</div>
<? } else if(!$username1) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else {
 $simpan = mysql_query("UPDATE user SET level = 'Reseller' WHERE username = '$username1'");
 if($simpan) { ?>
<strong>Detail Upgrade Member Ke Reseller !</strong>
<br>======================</br>
<br><strong>Nama </strong>:<?php echo $dapat['nama']; ?></br>
<br><strong>Username </strong>:<?php echo $username1; ?></br>
<br><strong>Level Upgrade </strong>: Member Ke Re-Seller </br>
<br><strong>DiUpgrade oleh </strong>:<?php echo $username; ?></br>
<br>======================</br>

<strong>Status Sukses !</strong>
</div>
<? } else { ?>
ERROR
<? }
?>
<? }
?>