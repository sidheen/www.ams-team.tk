<?php
// Script by Sebastian Wirajaya Licensed

session_start();
if(!isset($_SESSION['username'])) {
header('location:login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$hasil = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $username1 = $_POST['username'];
  $password = $_POST['password'];
  $nama = $_POST['nama'];
  $level = $_POST['level'];
  $fbid = $_POST['fbid'];

if ($level == Member) {
$harga = 15000;
$bonus = 5000;
} else if ($level == Reseller) {
$harga = 100000;
$bonus = 50000;
} else if ($level == Agen) {
$harga = 30000;
$bonus = 15000;
} else if ($level == MemberFree) {
$harga = 10;
$bonus = 10;
} else {
$tiket = a;
}
  if ($hasil['saldo'] < $harga) { ?>
<div class="alert alert-danger">
Gagal : Saldo tidak mencukupi.
</div>
<? } else {
  $cekuser = mysql_query("SELECT * FROM user WHERE username = '$username1'");  
  if(mysql_num_rows($cekuser) <> 0) { ?>
<div class="alert alert-danger">
Gagal : Username sudah terdaftar.
</div>
<? } else if(!$username1 || !$password || !$nama) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else {
 
 $simpan = mysql_query("INSERT INTO user(fbid,username, password, nama, level, saldo, uplink) VALUES('$fbid','$username1', '$password', '$nama', '$level', '$bonus','$username')");
 $simpan = mysql_query("UPDATE user SET saldo=saldo-$harga WHERE username = '$username'");
 if($simpan) { ?>


<strong>Pendaftaran anggota baru sukses.<br /></strong>
=========================<br />

<strong>Nama :</strong> <?php echo $nama; ?> <br />
<strong>fbid :</strong> <?php echo $fbid; ?> <br />
<strong>Username :</strong> <?php echo $username1; ?> <br />
<strong>Password : </strong><?php echo $password; ?> <br />
<strong>Level :</strong> <?php echo $level; ?> <br />
<strong>Bonus Saldo :</strong> <?php echo $bonus; ?> <br />
<strong>Pendaftaran Oleh :</strong> <?php echo $username; ?> <br />
=========================<br />
</div></div>
										
										
									
</div>
<? } else { ?>
ERROR
<? }
?>
<? }
}
?>