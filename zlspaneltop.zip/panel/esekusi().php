 <?php
session_start();
include '../koneksi.php';

        $username = $_POST['username'];
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];
        $confirmnewpassword = $_POST['confirmnewpassword'];
        $result = mysql_query("SELECT password FROM user WHERE 
username='$username'");
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($password!= mysql_result($result, 0))
        {
        echo "Password Yang Anda Masukan Salah";
        }
        if($newpassword=$confirmnewpassword)
        $sql=mysql_query("UPDATE user SET password='$newpassword' where 

 username='$username'");
        if($sql)
        {
        echo "Ganti Password Berhasil Password Lama = $password diganti dengan = $newpassword";
        }
       else
        {
       echo "Passwords Tidak Sama";
       }
      ?>