<?php
// Script by Sebastian Wirajaya Licensed

session_start();
if(!isset($_SESSION['username'])) {
header('location:login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$hasil = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $kode = $_POST['kode'];
  $cekuser = mysql_query("SELECT * FROM vouchersaldo WHERE kode = '$kode'");  
 $data = mysql_num_rows($cekuser);
 $dapat = mysql_fetch_array($cekuser);

  if(!$kode) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else if ($data == 0) { ?>
<div class="alert alert-danger">
Gagal : Voucher Saldo tidak tersedia.
</div>
<? } else {
$isisaldo = $dapat['isi'];
 $simpan = mysql_query("UPDATE user SET saldo=saldo+$isisaldo WHERE username = '$username'");
 if($simpan) { ?>
<div class="panel panel-danger">
									<div class="panel-heading">
										<header><i class="fa fa-shopping-cart"></i>Top Up Saldo Berhasil !</header>

										<div class="panel-heading-tools">
											
										</div>
									</div>
									<div class="panel-body">

										
							
<strong>TopUp saldo sukses.<br /></strong>
====================<br />

<strong>Pembeli :</strong> <?php echo $username; ?> <br />
<strong>Isi Saldo :</strong> <?php echo $isisaldo; ?> <br />
<strong>Kode :</strong> <?php echo $kode; ?> <br />
====================<br />
</div></div>
										
										
									</div>
								</div>
							</div>
<?
mysql_query("DELETE FROM vouchersaldo WHERE kode='$kode'");
 } else { ?>
ERROR
<? }
?>
<? }
?>