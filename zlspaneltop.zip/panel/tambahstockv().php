<?php
// Script by Sebastian Wirajaya Licensed

session_start();
if(!isset($_SESSION['username'])) {
header('location:login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$hasil = mysql_fetch_array($query);
?>

<?php
  require_once("../koneksi.php");
  $jenis = $_POST['jenis'];
  $link = $_POST['link'];
  $harga = $_POST['harga'];
  $email = $_POST['email'];
  $passworde = $_POST['passworde'];

  $cekuser = mysql_query("SELECT * FROM orderphising WHERE jenis = '$jenis' && email = '$email'");  
  if(mysql_num_rows($cekuser) <> 0) { ?>
<div class="alert alert-danger">
Gagal : Web sudah distock.
</div>
<? } else if(!$link || !$harga || !$email) { ?>
<div class="alert alert-danger">
Gagal : Masih ada data yang kosong.
</div>
<? } else {
 $simpan = mysql_query("INSERT INTO orderphising(link, jenis, harga, email, passworde) VALUES('$link', '$jenis', '$harga', '$email', '$passworde')");
 if($simpan) { ?>
Penambahan web Phising Sukses.<br />
================================<br />

Jenis : <?php echo $jenis; ?> <br />
link : <?php echo $link; ?> <br />
Harga : <?php echo $harga; ?> <br />
Email : <?php echo $email; ?> <br />
Password Email : <?php echo $passworde; ?> <br />
================================<br />
</div>
<? } else { ?>
ERROR
<? }
?>
<? }
?>