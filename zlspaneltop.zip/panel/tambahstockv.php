<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>
<?php if($get['level'] !== Admin) { ?>
<div class="alert alert-danger">
Gagal : Tidak ada akses
</div>
<? } else { ?>
				<div class="panel-heading">
					<h2>Tambah Stock Web Phising</h2>
				</div>
				<div class="panel-body"> 
   

                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Jenis Web</label>
                                            <div class="col-md-9">                                        
                                                <select class="form-control select" id="jenis" name="jenis">
<option value="COC">COC</option>

                                                </select>
                                            </div>
                                        </div>
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">link web</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="link" id="link" placeholder="link web"/>
                                            </div>
                                        </div>           
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Harga</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="harga" id="harga" placeholder="Harga"/>
                                            </div>
                                        </div>           
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Email</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="email" id="email" placeholder="Email "/>
                                            </div>
                                        </div>           
<br />
<div class="form-group">
                                            <label class="col-md-3 control-label">Password Email</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="passworde" id="passworde" placeholder="Password Email "/>
                                            </div>
                                        </div>           
<br />
                                        <div class="form-group">
<button class="btn btn-primary btn-block" id="btnLogin" onclick="tambahstockv();" ><i class="fa fa-mail-forward" name="proces" type="submit"></i> Submit</button> 
                                        </div>
                                </div>

<script>
function tambahstockv()
{
post();
	var jenis = $('#jenis').val();
	var link = $('#link').val();
	var harga = $('#harga').val();
	var email = $('#email').val();
        var passworde = $('#passworde').val();
	$.ajax({
		url	: 'panel/tambahstockv().php',
		data	: 'jenis='+jenis+'&link='+link+'&harga='+harga+'&email='+email+'&passworde='+passworde,
		type	: 'POST',
		dataType: 'html',
		success	: function(result){
hasil();
	$("#result").html(result);
	}
	});
}
</script>

<? } ?>