<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>
<div class="panel-heading">
					<span class="panel-title">Ganti Password</span>
				</div>
				<div class="panel-body"> 

                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Username</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="username" id="username" placeholder="Username Saat Ini"/>
                                            </div>
                                        </div>           
<br />
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Password Lama</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="password" id="password" placeholder="password"/>
                                            </div>
                                        </div>           
<br />
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Password Baru</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="newpassword" id="newpassword" placeholder="Password Baru"/>
                                            </div>
                                        </div>           
<br />
<br />
      <div class="form-group">
                                            <label class="col-md-3 control-label">Konfirm Password Baru</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="confirmpassword" id="confirmnewpassword" placeholder="Konfirm Password Baru"/>
                                            </div>
                                        </div>           
<br />                                  
                                         
<br />
                                        <div data-toggle="modal" data-target="#zonk" class="form-group">
<button class="btn btn-primary btn-block" id="btnLogin" onclick="esekusi();" ><i class="fa fa-mail-forward" name="proces" type="submit"></i> Submit</button> 
                                        </div>

<div class="alert alert-info">
Harap Masukan Data Dengan Benar
</div>
                                </div>

<script>
function esekusi()
{
post();
	var username = $('#username').val();
	var password = $('#password').val();
	var newpassword = $('#newpassword').val();
	var confirmnewpassword = $('#confirmnewpassword').val();
	$.ajax({
		url	: 'panel/esekusi().php',
		data	: 'username='+username+'&password='+password+'&newpassword='+newpassword+'&confirmnewpassword='+confirmnewpassword,
		type	: 'POST',
		dataType: 'html',
		success	: function(result){
hasil();
	$("#result").html(result);
	}
	});
}
</script>

<? 
 ?>