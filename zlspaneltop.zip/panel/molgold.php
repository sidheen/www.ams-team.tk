<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>
<div class="widget">
							<h4 class="widgettitle">Monster Legend Gold</h4>
							<div class="widgetcontent">
<p>

<label>FBID</label>
<span class="field"><input type="text" name="fbid" class="input-large" placeholder="Masukkan FBID" value="<?PHP echo $_POST['fbid']?>"/></span>
	</p>
                        <p>
                            <label>Paket</label>
                            <span class="field">
                            <select value="<?PHP echo $_POST['jumlah']; ?>" name="jumlah" id="jumlah" class="uniformselect">
			<option VALUE="20">Custom</option>      
			<option VALUE="40">1M Gold</option>     
			<option VALUE="60">2M Gold</option>     
			<option VALUE="80">3M Gold</option>
</select>
</span>
<small class="desc">Minimal level 5 dan mempunyai Travern</small>
</p>
<input type="hidden" name="proces"/>
									<p>
									<label></label>
									<span class="field">
										<button name="proces" class="btn btn-primary"><i class="iconfa-share-alt iconfa-white" name="proces" type="submit"></i>  Submit</button> 
										<button type="reset" class="btn"><i class="iconfa-refresh iconfa-black"></i> Reset</button>
									</span>
									</p>

</div></div>
<script>
function cek()
{
post();
	var idord = $('#idord').val();
	$.ajax({
		url	: 'panel/+molgold.php.php',
		data	: 'fbid='+fbid,
		type	: 'POST',
		dataType: 'html',
		success	: function(result){
hasil();
	$("#result").html(result);
	}
	});
}
</script>

<? } ?>