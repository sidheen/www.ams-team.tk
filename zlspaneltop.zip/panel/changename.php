<?php
//Script by Sebastian Wirajaya

session_start();

if(!isset($_SESSION['username'])) {
header('location:../login.php'); }
else { $username = $_SESSION['username']; }
require_once("../koneksi.php");

$query = mysql_query("SELECT * FROM user WHERE username = '$username'");
$get = mysql_fetch_array($query);
?>
<div class="panel-heading">
					<span class="panel-title">Ganti Nama</span>
				</div>
				<div class="panel-body"> 

                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Username</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="username" id="username" placeholder="Username Saat Ini"/>
                                            </div>
                                        </div>           
<br />
                                         
<br />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Nama Baru</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="newname" id="newname" placeholder="Nama Baru"/>
                                            </div>
                                        </div>           
<br />
      <div class="form-group">
                                            <label class="col-md-3 control-label">Konfirm Nama Baru</label>
                                            <div class="col-md-9">                                      
                                            <input type="text" class="form-control" name="confirmnewname" id="confirmnewname" placeholder="Konfirm Nama Baru"/>
                                            </div>
                                        </div>           
<br />                                  
                                         
<br />
                                        <div data-toggle="modal" data-target="#zonk" class="form-group">
<button class="btn btn-primary btn-block" id="btnLogin" onclick="esekusi1();" ><i class="fa fa-mail-forward" name="proces" type="submit"></i> Submit</button> 
                                        </div>

<div class="alert alert-info">
Harap Masukan Data Dengan Benar
</div>
                                </div>

<script>
function esekusi1()
{
post();
	var username = $('#username').val();
	
	var newname = $('#newname').val();
	var confirmnewname = $('#confirmnewname').val();
	$.ajax({
		url	: 'panel/esekusi1().php',
		data	: 'username='+username+'&newname='+newname+'&confirmnewname='+confirmnewname,
		type	: 'POST',
		dataType: 'html',
		success	: function(result){
hasil();
	$("#result").html(result);
	}
	});
}
</script>

<? 
 ?>