 <?php
session_start();
include '../koneksi.php';

        $username = $_POST['username'];
        
        $newname = $_POST['newname'];
        $confirmnewname = $_POST['confirmnewname'];
        $result = mysql_query("SELECT nama FROM user WHERE 
username='$username'");
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($newname!= mysql_result($result, 0))
        {
        echo "";
        }
        if($newname=$confirmnewname)
        $sql=mysql_query("UPDATE user SET nama='$newname' where 

 username='$username'");
        if($sql)
        {
        echo "Ganti Nama Berhasil diganti dengan = $newname";
        }
       else
        {
       echo "Nama Tidak Sama";
       }
      ?>